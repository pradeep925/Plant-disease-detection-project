from flask import Flask, request, jsonify
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
from flask_cors import CORS
import numpy as np

app = Flask(__name__)
CORS(app)
# Load the model and class mapping
model = load_model('plant_disease_detection.h5')

class_mapping = {
  0: "Cherry_(including_sour)___Powdery_mildew",
  1: "Cherry_(including_sour)___healthy",
  2: "Corn_(maize)___healthy",
  3: "Grape___Black_rot",
  4: "Grape___Esca_(Black_Measles)",
  5: "Grape___healthy",
  6: "Healthy_Pigeon",
  7: "Leaf_Spot_Pigeon",
  8: "Moisaic_Pigeon",
  9: "Tomato___Bacterial_spot",
  10: "Tomato___Early_blight",
  11: "Tomato___Late_blight",
  12: "Tomato___Leaf_Mold",
  13: "Tomato___healthy"
}

def preprocess_image(img_path):
    img = image.load_img(img_path, target_size=(224, 224))
    img_array = image.img_to_array(img)
    img_array = np.expand_dims(img_array, axis=0)
    img_array /= 255.0
    return img_array

@app.route('/predict', methods=['POST'])
def predict():
    if 'image' not in request.files:
        return jsonify({'error': 'No file part'})

    file = request.files['image']
    img_path = 'temp.jpg'
    file.save(img_path)

    img_array = preprocess_image(img_path)
    predictions = model.predict(img_array)
    predicted_class_index = np.argmax(predictions)
    predicted_class_name = class_mapping[predicted_class_index]

    # Calculate accuracy percentage
    accuracy_percentage = predictions[0][predicted_class_index] * 100

    return jsonify({
        'predicted_class': predicted_class_name,
        'accuracy_percentage': round(accuracy_percentage, 2)  # Round to 2 decimal places
    })

if __name__ == '__main__':
    app.run(debug=True)
